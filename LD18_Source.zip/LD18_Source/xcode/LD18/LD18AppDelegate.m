//
//  LD18AppDelegate.m
//  LD18
//
//  Created by Philip Cooper-King on 22/08/2010.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import "LD18AppDelegate.h"

@implementation LD18AppDelegate

@synthesize window;

- (void)applicationDidFinishLaunching:(NSNotification *)aNotification {
	// Insert code here to initialize your application 
}

@end
