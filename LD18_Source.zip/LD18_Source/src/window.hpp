// windows.hpp

#ifndef __window_hpp__
#define __window_hpp__


#include <Gosu/Gosu.hpp>
#include "object_manager.hpp"

Gosu::Window& windowInstance();


#endif